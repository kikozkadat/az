# strategy/scorer.py - Optimalizált verzió FÜGGETLEN MOZGÁSOKKAL

import time
import numpy as np
from typing import Dict, List, Optional
import math
import logging # Hozzáadva a naplózáshoz

logger = logging.getLogger(__name__) # Hozzáadva a naplózáshoz

class CoinScorer:
    def __init__(self, blacklist=None, whitelist=None):
        self.blacklist = blacklist or {}
        self.whitelist = whitelist or {}
        self.last_check = {}
        
        # 🎯 OPTIMALIZÁLT SÚLYOK - FÜGGETLEN MOZGÁSOK FÓKUSZ
        self.weights = {
            'volume_spike': 0.30,           # 30% - Volume spike a legfontosabb
            'bollinger_breakout': 0.25,     # 25% - Bollinger kitörés
            'rsi_momentum': 0.18,           # 18% - RSI momentum
            'price_action': 0.12,           # 12% - Ár akció
            'volatility': 0.08,             # 8% - Volatilitás
            'correlation': 0.03,            # 3% - BTC/ETH korreláció (csökkentve!)
            'independence_bonus': 0.02,     # 2% - Független mozgás bónusz
            'liquidity': 0.02               # 2% - Likviditás
        }
        
        # Mikro-trading thresholds
        self.thresholds = {
            'min_volume_24h': 100000,           # Min $100K volume
            'max_volume_24h': 50000000,         # Max $50M volume
            'ideal_volatility_range': (0.02, 0.08),  # 2-8% volatilitás
            'rsi_oversold': 30,
            'rsi_overbought': 70,
            'rsi_neutral_zone': (40, 60),
            'volume_spike_threshold': 2.0,       # 2x volume spike
            'mega_pump_threshold': 5.0,          # 5x mega pump
            'correlation_strength': 0.6,         # CSÖKKENTETT korrelációs küszöb
            'price_momentum_threshold': 0.005,   # 0.5% momentum
            'independence_threshold': 0.4        # Független mozgás küszöb
        }

    def score_coin(self, coin: Dict) -> float:
        """
        Optimalizált pontozás FÜGGETLEN MOZGÁSOKKAL
        """
        try:
            total_score = 0.0
            
            # Blacklist check
            symbol = coin.get('symbol', '')
            if self._is_blacklisted(symbol):
                return -100 # Vagy egy speciális érték a feketelistázott coinok jelzésére
            
            # 1. VOLUME SPIKE ANALYSIS (30% súly - növelve!)
            volume_score = self._calculate_volume_score(coin)
            total_score += volume_score * self.weights['volume_spike']
            
            # 2. BOLLINGER BREAKOUT ANALYSIS (25% súly - növelve!)
            bb_score = self._calculate_bollinger_score(coin) # Ez a metódus lesz frissítve
            total_score += bb_score * self.weights['bollinger_breakout']
            
            # 3. RSI MOMENTUM ANALYSIS (18% súly)
            rsi_score = self._calculate_rsi_momentum_score(coin)
            total_score += rsi_score * self.weights['rsi_momentum']
            
            # 4. PRICE ACTION ANALYSIS (12% súly)
            price_score = self._calculate_price_action_score(coin)
            total_score += price_score * self.weights['price_action']
            
            # 5. VOLATILITY ANALYSIS (8% súly)
            vol_score = self._calculate_volatility_score(coin)
            total_score += vol_score * self.weights['volatility']
            
            # 6. CORRELATION ANALYSIS (3% súly - DRASZTIKUSAN CSÖKKENTETT!)
            corr_score = self._calculate_correlation_score(coin)
            total_score += corr_score * self.weights['correlation']
            
            # 7. INDEPENDENCE BONUS (2% súly - ÚJ!)
            independence_score = self._calculate_independence_bonus(coin)
            total_score += independence_score * self.weights['independence_bonus']
            
            # 8. LIQUIDITY ANALYSIS (2% súly)
            liq_score = self._calculate_liquidity_score(coin)
            total_score += liq_score * self.weights['liquidity']
            
            # BONUS/PENALTY MODIFIERS
            total_score = self._apply_bonus_penalties(coin, total_score)
            
            # Final normalization
            final_score = max(0.0, min(10.0, total_score)) # Biztosítjuk, hogy 0 és 10 között legyen
            
            coin['score'] = final_score
            coin['score_breakdown'] = self._get_score_breakdown(coin) # Pontszám részletezés hozzáadása
            
            return final_score
            
        except Exception as e:
            logger.error(f"[SCORER] Error scoring {coin.get('symbol', 'unknown')}: {e}", exc_info=True)
            return 0.0

    def _calculate_volume_score(self, coin: Dict) -> float:
        """Volume spike elemzés - még fontosabb lett"""
        try:
            volume_last = coin.get('volume_last', 0.0)
            volume_avg = coin.get('volume_15m_avg', 1.0) # Alapértelmezett 1.0 a nullosztás elkerülése érdekében
            volume_24h = coin.get('volume_24h', volume_last * 96) # Becsült 24 órás volumen, ha nincs explicit adat
            
            # Biztosítjuk, hogy volume_avg ne legyen nulla
            if volume_avg == 0:
                volume_avg = 1.0 
                
            volume_ratio = volume_last / volume_avg
            score = 0.0
            
            # Alapvető volume követelmények
            if volume_24h < self.thresholds['min_volume_24h']:
                return 0.0 # Túl alacsony volumen, nincs pont
            
            if volume_24h > self.thresholds['max_volume_24h']:
                score -= 1.0  # Túl magas volumen (lehet pump-and-dump), csökkentett büntetés
            
            # Volume spike scoring - OPTIMALIZÁLT
            if volume_ratio >= self.thresholds['mega_pump_threshold']:
                score += 5.0  # Mega pump
            elif volume_ratio >= self.thresholds['volume_spike_threshold']:
                score += 4.0  # Jó spike - növelve
            elif volume_ratio >= 1.5:
                score += 2.5  # Mérsékelt spike - növelve
            elif volume_ratio >= 1.2:
                score += 1.0  # Kis spike - ÚJ kategória
            elif volume_ratio < 0.8: # Ha a volumen csökken az átlaghoz képest
                score -= 0.5  # Csökkentett büntetés
            
            # Tartós volume bónusz (ha a spike fennmarad)
            # Ezt nehéz egyetlen adatpontból megítélni, több idősíkos elemzés kellene
            # Jelenlegi implementációban a volume_ratio már ezt tükrözi.
            # Ha a `volume_last` magasabb, mint az `volume_15m_avg`, az már egyfajta tartósságot jelezhet.
            if volume_ratio > 1.3: # Ha a jelenlegi volume jelentősen meghaladja az átlagot
                score += 1.0  # Növelt bónusz
                
            return max(0.0, score) # Biztosítjuk, hogy a pontszám ne legyen negatív
            
        except Exception as e:
            logger.error(f"[SCORER] Volume score error for {coin.get('symbol', 'N/A')}: {e}", exc_info=True)
            return 0.0

    def _calculate_bollinger_score(self, coin: Dict) -> float:
        """Bollinger Bands breakout analysis - JAVÍTOTT NULLOSZTÁS KEZELÉSSEL"""
        try:
            price = coin.get('close', 0.0)
            
            # Ha nincs ár, nincs pontozás
            if price <= 0:
                logger.warning(f"Invalid price for Bollinger calculation in {coin.get('symbol', 'N/A')}: {price}")
                return 0.0
                
            bb_upper = coin.get('boll_3m_upper', price * 1.02) # Alapértelmezett érték, ha hiányzik
            bb_lower = coin.get('boll_3m_lower', price * 0.98) # Alapértelmezett érték, ha hiányzik
            
            # Validáció: sávoknak pozitívnak kell lenniük
            if bb_upper <= 0 or bb_lower <= 0:
                logger.warning(f"Invalid Bollinger bands for {coin.get('symbol', 'N/A')}: upper={bb_upper}, lower={bb_lower}")
                return 0.0
                
            # Ha a sávok egybeesnek (nagyon ritka, de elkerüli a nullosztást)
            if bb_upper == bb_lower:
                logger.warning(f"Bollinger bands are identical for {coin.get('symbol', 'N/A')}")
                return 0.0 # Nincs értelmezhető sávszélesség
                
            bb_middle = (bb_upper + bb_lower) / 2
            
            # További validáció: középső sávnak pozitívnak kell lennie
            if bb_middle <= 0:
                logger.warning(f"Invalid Bollinger middle for {coin.get('symbol', 'N/A')}: {bb_middle}")
                return 0.0
            
            score = 0.0
            
            # Band position analysis (Ár helyzete a sávokhoz képest)
            if price > bb_upper * 0.99: # Ár a felső sáv 99%-a felett (közelít vagy áttöri)
                score += 4.0  # Erős bullish jelzés (Breakout imminent)
            elif price > bb_upper * 0.97: # Ár a felső sáv 97%-a felett
                score += 3.0  # Mérsékelt bullish jelzés (Near breakout)
            elif price < bb_lower * 1.01: # Ár az alsó sáv 101%-a alatt (közelít vagy áttöri lefelé)
                score += 3.5  # Erős vételi jelzés (Oversold reversal) - magasabb pont, mert a visszapattanás esélyesebb
            elif price < bb_lower * 1.03: # Ár az alsó sáv 103%-a alatt
                score += 2.0  # Mérsékelt vételi jelzés (Near oversold)
            elif abs(price - bb_middle) / bb_middle < 0.005: # Ár nagyon közel a középső sávhoz (0.5% eltérés)
                score += 1.0  # Semleges, de stabil helyzet
            
            # Band width analysis (Sávszélesség analízis)
            band_width_abs = bb_upper - bb_lower # Abszolút sávszélesség
            # band_width_abs már > 0, mert bb_upper == bb_lower esetet kezeltük
            # bb_middle > 0 esetet is kezeltük
            
            band_width_ratio = band_width_abs / bb_middle # Relatív sávszélesség a középső sávhoz képest
            
            if 0.02 <= band_width_ratio <= 0.06: # Ideális sávszélesség (2-6%)
                score += 1.5  # Ideális volatilitás, jó kereskedési lehetőség
            elif band_width_ratio > 0.08: # Túl széles sáv (>8%)
                score -= 0.3  # Magas volatilitás, kockázatosabb
            elif band_width_ratio < 0.01: # Túl szűk sáv (<1%)
                score -= 0.5  # Alacsony volatilitás, "squeeze" előtti állapot lehet, de önmagában nem erős jel
            # else: A köztes esetek (pl. 0.01-0.02 vagy 0.06-0.08) nem kapnak se bónuszt, se levonást ebből a szempontból.
            # A logger.warning("Cannot calculate band width ratio") itt nem szükséges, mert a kritikus eseteket már fentebb kezeltük.
            
            return max(0.0, score)  # Biztosítjuk, hogy a pontszám ne legyen negatív
            
        except Exception as e:
            logger.error(f"[SCORER] Bollinger score error for {coin.get('symbol', 'N/A')}: {e}", exc_info=True)
            return 0.0

    def _calculate_correlation_score(self, coin: Dict) -> float:
        """BTC/ETH korreláció - DRASZTIKUSAN CSÖKKENTETT súly"""
        try:
            btc_corr = coin.get('correl_btc', 0.0)
            eth_corr = coin.get('correl_eth', 0.0)
            btc_is_breaking = coin.get('btc_is_breaking', False) # BTC aktívan mozog-e
            eth_is_breaking = coin.get('eth_is_breaking', False) # ETH aktívan mozog-e
            
            score = 0.0
            
            # CSAK akkor számít a korreláció, ha BTC/ETH aktívan mozog
            if btc_is_breaking and btc_corr > self.thresholds['correlation_strength']:  # Ha BTC mozog és a coin korrelál vele
                score += 1.5  # Csökkentett bónusz, mert a cél a független mozgás
            if eth_is_breaking and eth_corr > self.thresholds['correlation_strength'] - 0.1: # ETH-ra kicsit lazább
                score += 1.0  # Csökkentett bónusz
                
            # Mérsékelt korreláció már nem ad explicit bónuszt, inkább a függetlenséget díjazzuk.
            # Az alacsony korrelációt az `_calculate_independence_bonus` kezeli.

            # Túl magas korreláció büntetése - ENYHÍTVE, mert a fő hangsúly a függetlenségen van
            if abs(btc_corr) > 0.95 or abs(eth_corr) > 0.95: # Ha szinte tökéletesen követi a nagyokat
                score -= 0.5  # Kis büntetés, mert nem önálló
                
            return max(0.0, score) # Pontszám ne legyen negatív
            
        except Exception as e:
            logger.error(f"[SCORER] Correlation score error for {coin.get('symbol', 'N/A')}: {e}", exc_info=True)
            return 0.0

    def _calculate_independence_bonus(self, coin: Dict) -> float:
        """ÚJ: Független mozgás bónusz számítás"""
        try:
            btc_corr_abs = abs(coin.get('correl_btc', 0.7)) # Abszolút korreláció BTC-vel
            eth_corr_abs = abs(coin.get('correl_eth', 0.6)) # Abszolút korreláció ETH-val
            
            # Átlagos abszolút korreláció a nagyokkal
            avg_abs_correlation = (btc_corr_abs + eth_corr_abs) / 2.0
            
            volume_last = coin.get('volume_last', 0.0)
            volume_avg = coin.get('volume_15m_avg', 1.0)
            if volume_avg == 0: volume_avg = 1.0
            volume_ratio = volume_last / volume_avg # Volumen növekedési ráta

            price_change_5m_abs = abs(coin.get('price_change_5m', 0.0)) # 5 perces árváltozás abszolút értéke
            
            score = 0.0
            
            # Alacsony korreláció bónusz (minél alacsonyabb, annál jobb)
            if avg_abs_correlation < self.thresholds['independence_threshold']: # Ha az átlagos korreláció a küszöb alatt van
                # Lineárisan növekvő bónusz, ahogy a korreláció csökken
                independence_factor = (self.thresholds['independence_threshold'] - avg_abs_correlation) / self.thresholds['independence_threshold']
                score += independence_factor * 2.0 # Max 2.0 pont ebből
            
            # Volume spike független mozgással (erős jel)
            if volume_ratio > 2.0 and avg_abs_correlation < 0.6: # Jelentős volumen növekedés ÉS alacsony korreláció
                score += 2.0  # Nagy bónusz független volume spike-ért
            
            # Jelentős ármozgás alacsony korrelációval
            if price_change_5m_abs > 0.01 and avg_abs_correlation < 0.5: # 1% feletti árváltozás ÉS nagyon alacsony korreláció
                score += 1.5  # Független price action bónusz
            
            # Anti-követés bónusz (amikor BTC/ETH nem mozog, de a coin igen)
            btc_momentum_abs = abs(coin.get('btc_momentum', 0.0)) # BTC momentum abszolút értéke
            eth_momentum_abs = abs(coin.get('eth_momentum', 0.0)) # ETH momentum abszolút értéke
            
            # Ha a nagyok alig mozognak (pl. 0.2% alatti momentum), de a coinunk igen (pl. 0.5% feletti árváltozás)
            if btc_momentum_abs < 0.002 and eth_momentum_abs < 0.002 and price_change_5m_abs > 0.005:
                score += 2.0  # Nagy bónusz, mert a coin "önálló életet él"
                
            return min(5.0, max(0.0, score))  # Max 5.0 bónusz, és ne legyen negatív
            
        except Exception as e:
            logger.error(f"[SCORER] Independence bonus error for {coin.get('symbol', 'N/A')}: {e}", exc_info=True)
            return 0.0

    def _calculate_rsi_momentum_score(self, coin: Dict) -> float:
        """RSI alapú momentum scoring - kicsit módosítva"""
        try:
            rsi_3m = coin.get('rsi_3m', 50.0)   # Rövid távú RSI (3 perc)
            rsi_15m = coin.get('rsi_15m', 50.0) # Közép távú RSI (15 perc)
            
            score = 0.0
            
            # 3-minute RSI (short-term momentum)
            if self.thresholds['rsi_oversold'] <= rsi_3m <= self.thresholds['rsi_oversold'] + 10: # Pl. 30-40 között
                score += 3.5  # Erős vételi momentum (túladottból felfelé) - kicsit növelve
            elif self.thresholds['rsi_oversold'] + 10 < rsi_3m <= self.thresholds['rsi_neutral_zone'][0]: # Pl. 40-45 között (ha neutral_zone[0]=45)
                score += 2.5  # Mérsékelt vételi momentum - növelve
            elif self.thresholds['rsi_neutral_zone'][0] < rsi_3m <= self.thresholds['rsi_neutral_zone'][1]: # Semleges zóna, pl. 45-55
                score += 1.5  # Konszolidáció vagy enyhe momentum - növelve
            # Túlvett állapot büntetése
            elif rsi_3m > self.thresholds['rsi_overbought'] + 5: # Pl. 75 felett
                score -= 1.5  # Erősen túlvett, korrekció várható - csökkentett büntetés
            # Extrém túladott állapot büntetése (lehet csapda)
            elif rsi_3m < self.thresholds['rsi_oversold'] - 5: # Pl. 25 alatt
                score -= 0.5  # Nagyon túladott, lehet további esés - csökkentett büntetés
                
            # 15-minute RSI confirmation (megerősítés vagy ellentmondás)
            if self.thresholds['rsi_oversold'] <= rsi_15m <= self.thresholds['rsi_neutral_zone'][1]: # Ha a 15 perces is kedvező vagy semleges (pl. 30-60)
                score += 1.5 # Megerősíti a rövid távú jelet
            elif rsi_15m > self.thresholds['rsi_overbought']: # Ha a 15 perces már túlvett
                score -= 0.5  # Óvatosságra int - csökkentett büntetés
                
            # RSI divergencia bónusz (ha a rövid távú RSI erősebb, mint a közép távú)
            if rsi_3m > rsi_15m + 5: # Pl. 3m RSI = 50, 15m RSI = 40 -> pozitív divergencia
                score += 1.0
            # Negatív divergencia (ha a rövid távú gyengébb)
            elif rsi_3m < rsi_15m - 10: # Pl. 3m RSI = 30, 15m RSI = 50 -> negatív divergencia
                score -= 0.3  # Enyhe büntetés - csökkentett
                
            return max(0.0, score)
            
        except Exception as e:
            logger.error(f"[SCORER] RSI score error for {coin.get('symbol', 'N/A')}: {e}", exc_info=True)
            return 0.0

    def _calculate_price_action_score(self, coin: Dict) -> float:
        """Ár akció elemzés - kicsit módosítva"""
        try:
            price = coin.get('close', 0.0)
            price_change_5m = coin.get('price_change_5m', 0.0) # 5 perces árváltozás
            
            score = 0.0
            
            # Short-term momentum - OPTIMALIZÁLT
            # abs() használata, mert a momentum iránya önmagában nem mindig releváns a "jó beszállóra"
            price_change_5m_abs = abs(price_change_5m)

            if price_change_5m_abs > self.thresholds['price_momentum_threshold']: # Ha a momentum meghaladja a küszöböt (pl. 0.5%)
                if price_change_5m > 0: # Pozitív momentum
                    score += 2.5  # Erős pozitív momentum - növelve
                else: # Negatív momentum (lehet fordulópont vagy eső kés)
                    score += 1.5  # Negatív momentum is lehetőség (pl. túladott állapotból való felpattanás előtt) - növelve
            
            # Kis, de észrevehető momentum is számít
            if 0.002 <= price_change_5m_abs <= self.thresholds['price_momentum_threshold']: # Pl. 0.2% - 0.5% közötti mozgás
                score += 1.0  # Mérsékelt momentum bónusz
            
            # Price stability/volatility check (1 órás ár volatilitás)
            price_volatility_1h = coin.get('price_volatility_1h', 0.02) # Alapértelmezett 2%
            if 0.01 <= price_volatility_1h <= 0.05: # Ha az 1 órás volatilitás 1-5% között van (stabil, de nem unalmas)
                score += 1.2  # Növelt bónusz az ideális volatilitásért
            elif price_volatility_1h > 0.10: # Ha túl nagy a volatilitás (10% felett 1 órán belül)
                score -= 0.5  # Kockázatosabb - csökkentett büntetés
                
            return max(0.0, score)
            
        except Exception as e:
            logger.error(f"[SCORER] Price action score error for {coin.get('symbol', 'N/A')}: {e}", exc_info=True)
            return 0.0

    def _calculate_volatility_score(self, coin: Dict) -> float:
        """Volatilitás elemzés - változatlan"""
        try:
            volume_last = coin.get('volume_last', 0.0)
            volume_avg = coin.get('volume_15m_avg', 1.0)
            if volume_avg == 0: volume_avg = 1.0
            volume_ratio = volume_last / volume_avg

            price_range_1h = coin.get('price_range_1h', 0.02) # 1 órás ármozgás range (high-low)/low
            
            score = 0.0
            
            ideal_min, ideal_max = self.thresholds['ideal_volatility_range'] # Pl. (0.02, 0.08)
            
            if ideal_min <= price_range_1h <= ideal_max: # Ha az ármozgás az ideális tartományban van
                score += 2.0
            elif price_range_1h < ideal_min: # Túl alacsony volatilitás
                score += 0.5 # Kis bónusz, mert lehetőség "kitörés előtti állapotra"
            elif price_range_1h <= ideal_max * 1.5: # Kicsit magasabb, de még elfogadható volatilitás
                score += 1.0
            else: # Túl magas volatilitás
                score -= 1.0 # Kockázatos
                
            # Ha van volumen növekedés ÉS az ármozgás is megfelelő
            if volume_ratio > 2.0 and price_range_1h > ideal_min:
                score += 1.0 # Extra bónusz a volumen által támogatott volatilitásért
                
            return max(0.0, score)
            
        except Exception as e:
            logger.error(f"[SCORER] Volatility score error for {coin.get('symbol', 'N/A')}: {e}", exc_info=True)
            return 0.0

    def _calculate_liquidity_score(self, coin: Dict) -> float:
        """Likviditás elemzés - változatlan de csökkentett súly"""
        try:
            volume_24h = coin.get('volume_24h', coin.get('volume_last', 0.0) * 96) # Becsült 24ó volume
            
            score = 0.0
            
            if volume_24h > 1000000: # $1M feletti 24ó volume
                score += 1.0 # Jó likviditás
            elif volume_24h > 500000: # $500K feletti
                score += 0.5 # Elfogadható likviditás
            elif volume_24h < self.thresholds['min_volume_24h']: # Ha a min_volume_24h alatt van (pl. $100K)
                score -= 1.0 # Nagyon alacsony likviditás, büntetés
            else: # $100K - $500K között
                score -= 0.5 # Alacsony likviditás
                
            return max(0.0, score) # Pontszám ne legyen negatív (bár itt lehet negatív a büntetés miatt)
                                   # Jobb lenne, ha a score alapból 0-ról indulna és csak pozitív irányba változna,
                                   # vagy a negatív hatásokat a súlyozásnál kellene figyelembe venni.
                                   # Mostani logikával: max(0, score) a végén.
            
        except Exception as e:
            logger.error(f"[SCORER] Liquidity score error for {coin.get('symbol', 'N/A')}: {e}", exc_info=True)
            return 0.0

    def _apply_bonus_penalties(self, coin: Dict, base_score: float) -> float:
        """Bónuszok és büntetések - OPTIMALIZÁLT"""
        try:
            score = base_score
            
            # Whitelist bónusz
            if coin.get('symbol') in self.whitelist:
                score += 1.0 # Fix bónusz a whitelisted coinoknak
                
            # Recent success bónusz (ha a coin nemrég sikeres trade-eket produkált)
            # Ezt az adatot a PositionManager vagy egy külső statisztikai modul szolgáltathatná.
            # Tegyük fel, hogy a `coin` dict tartalmaz egy `recent_profit_streak` kulcsot.
            if coin.get('recent_profit_streak', 0) >= 3: # Ha legalább 3 egymást követő nyerő trade volt
                score += 0.5
            
            volume_last = coin.get('volume_last', 0.0)
            volume_avg = coin.get('volume_15m_avg', 1.0)
            if volume_avg == 0: volume_avg = 1.0
            volume_ratio = volume_last / volume_avg
            
            # Perfect storm bónusz - MÓDOSÍTOTT feltételek
            # Olyan helyzet, amikor több indikátor is egyszerre kedvező jelet ad.
            conditions_met = 0
            if volume_ratio > 2.0: conditions_met +=1 # Jelentős volumen növekedés
            
            rsi_3m = coin.get('rsi_3m', 50.0)
            if self.thresholds['rsi_oversold'] <= rsi_3m <= self.thresholds['rsi_neutral_zone'][0]: # Kedvező RSI tartomány (pl. 30-45)
                conditions_met +=1
            
            price = coin.get('close', 0.0)
            bb_upper = coin.get('boll_3m_upper', price * 1.02)
            if price > bb_upper * 0.97: # Közel a Bollinger felső sávhoz vagy felette
                conditions_met +=1
                
            avg_abs_correlation = (abs(coin.get('correl_btc', 0.7)) + abs(coin.get('correl_eth', 0.6))) / 2.0
            if avg_abs_correlation < 0.7: # Nem túl erősen korrelál a nagyokkal
                conditions_met +=1
            
            if conditions_met >= 3: # Ha legalább 3 feltétel teljesül
                score += 3.0  # Nagy "perfect storm" bónusz
            elif conditions_met == 2: # Ha 2 feltétel teljesül
                score += 1.5  # Kisebb bónusz
                
            # Független mozgás extra bónusz (ha nagyon kitűnik)
            if volume_ratio > 2.5 and avg_abs_correlation < 0.4: # Nagy volumen ÉS nagyon alacsony korreláció
                score += 2.0  # Nagy független mozgás bónusz
                
            # Időalapú büntetés (pl. éjszakai órákban, amikor kisebb a likviditás vagy nagyobb a manipuláció esélye)
            # Ezt a részt lehetne konfigurálhatóvá tenni.
            current_hour = time.localtime().tm_hour # Helyi idő órája
            if 2 <= current_hour <= 6: # Hajnali órák (feltételezve, hogy a fő piacok zárva)
                score -= 0.5  # Csökkentett aktivitás miatt enyhe büntetés
                
            return score # A normalizálás (0-10) a `score_coin` végén történik
            
        except Exception as e:
            logger.error(f"[SCORER] Bonus/penalty error for {coin.get('symbol', 'N/A')}: {e}", exc_info=True)
            return base_score # Hiba esetén visszatér az eredeti pontszámmal

    def _is_blacklisted(self, symbol: str) -> bool:
        """Check if symbol is blacklisted and the blacklist period is still active."""
        try:
            if symbol in self.blacklist:
                # A blacklist értéke a lejárat időpontja (timestamp)
                return self.blacklist[symbol] > time.time() 
            return False
        except Exception as e:
            logger.error(f"[SCORER] Error checking blacklist for {symbol}: {e}", exc_info=True)
            return False # Hiba esetén inkább ne tekintsük feketelistásnak

    def _get_score_breakdown(self, coin: Dict) -> Dict:
        """Get detailed score breakdown for analysis and logging."""
        try:
            # Újraszámoljuk a komponenseket, hogy a breakdown mindig friss legyen
            # és ne a score_coin közbeni állapotot tükrözze, ha pl. egy metódus többször hívódna.
            # Ez redundáns lehet, ha a score_coin már kiszámolta őket, de biztosítja a konzisztenciát.
            # Alternatíva: a score_coin metódus gyűjtse össze ezeket egy dict-be és adja át.
            # Most az egyszerűség kedvéért újraszámoljuk.
            breakdown = {
                'volume_score': self._calculate_volume_score(coin) * self.weights['volume_spike'],
                'bollinger_score': self._calculate_bollinger_score(coin) * self.weights['bollinger_breakout'],
                'rsi_score': self._calculate_rsi_momentum_score(coin) * self.weights['rsi_momentum'],
                'price_action_score': self._calculate_price_action_score(coin) * self.weights['price_action'],
                'correlation_score': self._calculate_correlation_score(coin) * self.weights['correlation'],
                'independence_score': self._calculate_independence_bonus(coin) * self.weights['independence_bonus'],
                'volatility_score': self._calculate_volatility_score(coin) * self.weights['volatility'],
                'liquidity_score': self._calculate_liquidity_score(coin) * self.weights['liquidity']
            }
            # A _apply_bonus_penalties hatását nehéz ide egyszerűen beilleszteni,
            # mert az a teljes súlyozott pontszámot módosítja.
            # Ezt a breakdown-t inkább a súlyozott komponensek bemutatására használjuk.
            return breakdown
        except Exception as e:
            logger.error(f"[SCORER] Error getting score breakdown for {coin.get('symbol', 'N/A')}: {e}", exc_info=True)
            return {}

    def select_best_coin(self, coin_list: List[Dict], min_score: float = 3.0) -> Optional[Dict]:
        """Legjobb coin kiválasztás - optimalizált logikával, figyelembe véve a független mozgást."""
        try:
            if not coin_list:
                return None
                
            scored_coins = []
            for coin_data in coin_list:
                # Fontos, hogy a score_coin itt fusson le, mert az tölti fel a 'score' és 'score_breakdown' mezőket
                current_score = self.score_coin(coin_data) 
                if current_score >= min_score:
                    # A coin_data már tartalmazza a 'score'-t és a 'score_breakdown'-t a score_coin hívás után
                    scored_coins.append(coin_data) 
            
            if not scored_coins:
                return None
                
            # Rendezés elsődlegesen a pontszám szerint csökkenőleg
            # Másodlagosan a függetlenségi pontszám szerint (ha van ilyen expliciten tárolva)
            # Tegyük fel, hogy az _calculate_independence_bonus eredményét is el akarjuk tárolni a coin dict-ben
            # vagy itt újra számoljuk a rendezéshez.
            
            # Rendezés a coin dict-ben lévő 'score' alapján.
            # Ha a függetlenséget jobban akarjuk súlyozni a kiválasztásnál, azt a score_coin-ban kellene jobban figyelembe venni,
            # vagy itt egyedi rendezési kulcsot használni.
            
            # Mostani egyszerűsített logika: a legmagasabb pontszámú, alkalmas coint választjuk.
            scored_coins.sort(key=lambda c: c.get('score', 0.0), reverse=True)
            
            # Keressük az első olyan coint a listában, ami alkalmas mikro-tradingre
            for best_coin_candidate in scored_coins:
                if self._is_suitable_for_micro_trading(best_coin_candidate):
                    return best_coin_candidate # Visszaadjuk az első alkalmas, legmagasabb pontszámú coint
            
            # Ha egyik sem volt alkalmas a top pontszámúak közül, akkor nincs kiválasztott coin
            logger.warning("[SCORER] No suitable coin found for micro-trading among the scored ones.")
            return None # Vagy a legmagasabb pontszámút adjuk vissza figyelmeztetéssel, ha nincs "suitable"
            
        except Exception as e:
            logger.error(f"[SCORER] Best coin selection error: {e}", exc_info=True)
            return None

    def _is_suitable_for_micro_trading(self, coin: Dict) -> bool:
        """Mikro-trading alkalmasság - enyhített feltételek, de alapvető ellenőrzésekkel."""
        try:
            # Alapvető adatok megléte
            required_fields = ['symbol', 'close', 'volume_last', 'volume_24h']
            if not all(field in coin and coin[field] is not None for field in required_fields):
                logger.warning(f"Coin {coin.get('symbol', 'N/A')} missing required fields for suitability check.")
                return False

            # Volumen ellenőrzés
            volume_24h = coin['volume_24h']
            if volume_24h < self.thresholds['min_volume_24h']: # Túl alacsony 24 órás volumen
                # logger.debug(f"Coin {coin['symbol']} unsuitable: low 24h volume ({volume_24h})")
                return False
            if volume_24h > self.thresholds['max_volume_24h']: # Túl magas volumen (lehet kockázatos)
                # logger.debug(f"Coin {coin['symbol']} unsuitable: too high 24h volume ({volume_24h})")
                return False # Ezt a feltételt lehet lazítani vagy kivenni, ha a magas volumen nem kizáró ok
                
            # RSI határok ellenőrzése (ne legyen extrém túlvett vagy túladott)
            rsi_3m = coin.get('rsi_3m', 50.0)
            if rsi_3m < 15 or rsi_3m > 85:  # Enyhített, de extrém értékeket kiszűrő RSI feltételek
                # logger.debug(f"Coin {coin['symbol']} unsuitable: extreme RSI ({rsi_3m})")
                return False
                
            # Ár volatilitás ellenőrzése (ne legyen extrém volatilis)
            price_volatility_1h = coin.get('price_volatility_1h', 0.02)
            if price_volatility_1h > 0.20:  # Túl magas 1 órás volatilitás (20% felett)
                # logger.debug(f"Coin {coin['symbol']} unsuitable: extreme 1h volatility ({price_volatility_1h})")
                return False
                
            return True # Ha minden ellenőrzésen átment
            
        except Exception as e:
            logger.error(f"[SCORER] Suitability check error for {coin.get('symbol', 'N/A')}: {e}", exc_info=True)
            return False # Hiba esetén nem tekintjük alkalmasnak

    def get_top_opportunities(self, coin_list: List[Dict], top_n: int = 5) -> List[Dict]:
        """Top lehetőségek független mozgás prioritással, részletes adatokkal."""
        try:
            opportunities = []
            
            for coin_data in coin_list:
                # A score_coin frissíti a coin_data-t 'score' és 'score_breakdown' kulcsokkal
                self.score_coin(coin_data) 
                
                # Csak akkor vesszük figyelembe, ha van pozitív pontszáma és alkalmas
                if coin_data.get('score', 0.0) > 0 and self._is_suitable_for_micro_trading(coin_data):
                    # A függetlenségi bónusz már része a teljes pontszámnak a score_coin logikája szerint.
                    # Ha külön is ki akarjuk emelni, akkor az _calculate_independence_bonus-t újra hívhatjuk,
                    # vagy a score_breakdown-ból vehetjük.
                    independence_raw_score = self._calculate_independence_bonus(coin_data) # Nyers függetlenségi pont
                    
                    opportunities.append({
                        'coin_data': coin_data, # A teljes coin dict, benne a 'score', 'score_breakdown' stb.
                        'symbol': coin_data.get('symbol', 'UNKNOWN'),
                        'final_score': coin_data.get('score', 0.0),
                        'independence_metric': independence_raw_score, # Külön a nyers függetlenségi érték
                        'breakdown_weighted': coin_data.get('score_breakdown', {}), # Súlyozott részletezés
                        'confidence_percent': min(100.0, coin_data.get('score', 0.0) * 10.0), # Pontszám 0-10 skálán -> 0-100%
                        'risk_level': self._assess_risk_level(coin_data, coin_data.get('score', 0.0)),
                        'avg_correlation_abs': (abs(coin_data.get('correl_btc', 0.7)) + abs(coin_data.get('correl_eth', 0.6))) / 2.0
                    })
            
            if not opportunities:
                return []

            # Rendezés: elsődlegesen a függetlenségi metrika (magasabb jobb),
            # másodlagosan a végső pontszám (magasabb jobb) szerint.
            opportunities.sort(
                key=lambda x: (x['independence_metric'], x['final_score']), 
                reverse=True
            )
            
            return opportunities[:top_n] # Visszaadja a top N lehetőséget
            
        except Exception as e:
            logger.error(f"[SCORER] Top opportunities error: {e}", exc_info=True)
            return []

    def _assess_risk_level(self, coin: Dict, score: float) -> str:
        """Kockázat értékelés a coin adatai és pontszáma alapján."""
        try:
            volume_last = coin.get('volume_last', 0.0)
            volume_avg = coin.get('volume_15m_avg', 1.0)
            if volume_avg == 0: volume_avg = 1.0
            volume_ratio = volume_last / volume_avg
            
            rsi_3m = coin.get('rsi_3m', 50.0)
            avg_abs_correlation = (abs(coin.get('correl_btc', 0.7)) + abs(coin.get('correl_eth', 0.6))) / 2.0
            price_volatility_1h = coin.get('price_volatility_1h', 0.02)

            risk_points = 0
            
            # Magas volumen spike növelheti a kockázatot (pump-and-dump gyanú)
            if volume_ratio > 5.0: risk_points += 2
            elif volume_ratio > 3.0: risk_points += 1
                
            # Extrém RSI értékek
            if rsi_3m < 20 or rsi_3m > 80: risk_points += 1
                
            # Túl magas korreláció (ha a nagyok esnek, ez is esni fog)
            if avg_abs_correlation > 0.9: risk_points += 1
            
            # Nagyon alacsony pontszám is kockázatot jelezhet
            if score < 2.0: risk_points += 1

            # Extrém volatilitás
            if price_volatility_1h > 0.15: # 15% feletti 1 órás volatilitás
                risk_points += 2
            elif price_volatility_1h > 0.10: # 10% feletti
                risk_points +=1
                
            if risk_points >= 4: return "VERY_HIGH"
            elif risk_points >= 3: return "HIGH"
            elif risk_points >= 2: return "MEDIUM"
            else: return "LOW"
                
        except Exception as e:
            logger.error(f"[SCORER] Risk assessment error for {coin.get('symbol', 'N/A')}: {e}", exc_info=True)
            return "UNKNOWN" # Hiba esetén ismeretlen a kockázat

    def blacklist_coin(self, symbol: str, duration_seconds: int = 86400, reason: str = "Auto blacklist"):
        """Coin hozzáadása a feketelistához egy adott időtartamra."""
        try:
            expiry_time = time.time() + duration_seconds
            self.blacklist[symbol] = expiry_time
            logger.info(f"[SCORER] Blacklisted {symbol} until {time.ctime(expiry_time)} ({duration_seconds // 3600} hours). Reason: {reason}")
        except Exception as e:
            logger.error(f"[SCORER] Blacklist error for {symbol}: {e}", exc_info=True)

    def whitelist_coin(self, symbol: str):
        """Coin hozzáadása a fehérlistához."""
        try:
            self.whitelist[symbol] = True # A whitelist értéke itt egyszerűen True lehet
            logger.info(f"[SCORER] Whitelisted {symbol}")
        except Exception as e:
            logger.error(f"[SCORER] Whitelist error for {symbol}: {e}", exc_info=True)

    def get_scoring_stats(self) -> Dict:
        """Scoring statisztikák és konfiguráció lekérdezése."""
        return {
            'weights': self.weights.copy(),
            'thresholds': self.thresholds.copy(),
            'active_blacklist_count': len([s for s, exp in self.blacklist.items() if exp > time.time()]),
            'whitelist_count': len(self.whitelist)
        }

