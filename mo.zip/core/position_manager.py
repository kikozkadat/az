# core/position_manager.py

import time
from typing import Dict, Optional, List
import logging

logger = logging.getLogger(__name__)

class PositionManager:
    def __init__(self, max_positions: int = 5, api_client=None):
        """
        PositionManager konstruktor.
        Lehetővé teszi a maximális pozíciók számának és egy API kliensnek a megadását.

        Args:
            max_positions (int): Az egyidejűleg nyitva tartható pozíciók maximális száma.
            api_client: Az API műveletekhez használandó kliens objektum (opcionális).
        """
        self.positions: Dict[str, dict] = {}  # kulcs: pair, érték: pozíció adatok
        self.max_positions = max_positions
        self.position_history: List[dict] = []
        self._trade_manager = None  # Lazy loading miatt None
        self.api_client = api_client  # Opcionális API kliens

        # max_positions validálása és naplózása
        if not isinstance(self.max_positions, int):
            logger.error(f"Invalid max_positions type: {type(self.max_positions)}. Defaulting to 5.")
            self.max_positions = 5  # Alapértelmezett érték helytelen típus esetén
        
        logger.info(f"PositionManager initialized with max_positions={self.max_positions}")
        if self.api_client:
            logger.info(f"PositionManager initialized with an API client: {type(api_client)}")

    def set_api_client(self, api_client):
        """
        API kliens beállítása vagy frissítése.

        Args:
            api_client: Az API műveletekhez használandó kliens objektum.
        """
        self.api_client = api_client
        logger.info(f"API client set for PositionManager: {type(api_client)}")

    @property
    def trade_manager(self):
        """
        Lazy load TradeManager to avoid circular import.
        Megjegyzés: Ha a TradeManager-nek szüksége van az api_client-re,
        akkor itt kellene átadni neki: self._trade_manager = TradeManager(api_client=self.api_client)
        feltéve, hogy a TradeManager konstruktora ezt támogatja.
        """
        if self._trade_manager is None:
            from core.trade_manager import TradeManager  # Import csak amikor először kell
            # TODO: Fontold meg az api_client átadását a TradeManager-nek, ha szükséges
            # pl. self._trade_manager = TradeManager(api_client=self.api_client)
            self._trade_manager = TradeManager()
            if self.api_client and hasattr(self._trade_manager, 'set_api_client'):
                 logger.info("Attempting to set API client for TradeManager.")
                 self._trade_manager.set_api_client(self.api_client)
            elif self.api_client:
                 logger.warning("PositionManager has an API client, but TradeManager might not be using it or doesn't have a set_api_client method.")

        return self._trade_manager
        
    def open_position(self, pair: str, side: str, entry_price: float, volume: float, 
                     stop_loss: Optional[float] = None, take_profit: Optional[float] = None,
                     entry_time_unix: Optional[float] = None, reason: Optional[str] = None) -> bool:
        """
        Új pozíció nyitása - ÉLES KERESKEDÉSSEL
        
        Args:
            pair: Trading pair (pl. "BTCUSD")
            side: "buy" vagy "sell"
            entry_price: Belépési ár
            volume: Pozíció mérete
            stop_loss: Stop loss ár (opcionális)
            take_profit: Take profit ár (opcionális)
            entry_time_unix: Pozíció nyitásának unix timestamp-je (opcionális)
            reason: Pozíció nyitásának oka (opcionális)
            
        Returns:
            bool: Sikeres volt-e a pozíció nyitása
        """
        try:
            # Ellenőrzések
            if pair in self.positions:
                logger.warning(f"Position already exists for {pair}")
                return False
                
            if len(self.positions) >= self.max_positions:
                logger.warning(f"Maximum positions ({self.max_positions}) reached. Cannot open new position for {pair}.")
                return False
                
            if volume <= 0 or entry_price <= 0:
                logger.error(f"Invalid volume or price for {pair}: volume={volume}, entry_price={entry_price}")
                return False
            
            # BTC/ETH TILTÁS - ezeket csak szignálként figyeljük!
            # Normalizáljuk a párok nevét az ellenőrzéshez (pl. XBTUSD -> BTCUSD)
            normalized_pair = pair.upper().replace('XBT', 'BTC').replace('ZUSD', 'USD')
            forbidden_pairs = ['BTCUSD', 'ETHUSD']
            if any(fp in normalized_pair for fp in forbidden_pairs):
                logger.warning(f"[POSITION] ❌ {pair} ({normalized_pair}) is FORBIDDEN - used as signal only!")
                return False
                
            # Entry time meghatározása
            if entry_time_unix is None:
                entry_time_unix = time.time()
            
            # VALÓDI ORDER KÜLDÉSE AZ API-NAK (TradeManager-en keresztül)
            logger.info(f"[POSITION] 🚀 Attempting to send REAL order via TradeManager: {pair} {side} {volume}")
            
            # Ellenőrizzük, hogy a trade_manager elérhető-e
            if not self.trade_manager:
                logger.error("[POSITION] ❌ TradeManager is not available. Cannot place order.")
                return False

            order_result = self.trade_manager.place_order(
                pair=pair,
                side=side,
                order_type="market", # Javasolt a market order explicit megadása
                volume=str(volume),
                # price=None # Market order esetén nem szükséges, de a Kraken API kérheti bizonyos ordertípusoknál
            )
            
            # Ellenőrizzük a TradeManager válaszát
            if not order_result:
                logger.error(f"[POSITION] ❌ Order placement FAILED for {pair} - no response from TradeManager.")
                return False
                
            # Az order_result struktúrája függ a TradeManager implementációjától
            # Tegyük fel, hogy hibát egy 'error' kulcs jelez, sikert pedig egy 'result' kulcs alatti 'txid'
            if order_result.get('error'): # Feltételezve, hogy az error lista vagy string
                error_message = order_result['error']
                if isinstance(error_message, list): error_message = ", ".join(error_message)
                logger.error(f"[POSITION] ❌ Order placement FAILED for {pair}: {error_message}")
                return False
            
            kraken_txid = None
            if order_result.get('result') and order_result['result'].get('txid'):
                # A txid lehet lista, vegyük az elsőt, ha van
                txid_list = order_result['result']['txid']
                if isinstance(txid_list, list) and len(txid_list) > 0:
                    kraken_txid = txid_list[0]
                elif isinstance(txid_list, str): # Ha a txid stringként jön vissza
                    kraken_txid = txid_list

                if kraken_txid:
                    logger.info(f"[POSITION] ✅ Order placement SUCCESS for {pair} - TXID: {kraken_txid}")
                else:
                    logger.warning(f"[POSITION] ⚠️ Order placement for {pair} reported success, but no TXID found in response: {order_result}")
            else:
                logger.warning(f"[POSITION] ⚠️ Order placement for {pair} response did not contain expected TXID: {order_result}")


            # Pozíció létrehozása
            position = {
                "pair": pair,
                "side": side.lower(),
                "entry_price": float(entry_price),
                "volume": float(volume),
                "stop_loss": float(stop_loss) if stop_loss is not None else None,
                "take_profit": float(take_profit) if take_profit is not None else None,
                "open_time": float(entry_time_unix),
                "entry_time_unix": float(entry_time_unix), # Kompatibilitás
                "unrealized_pnl": 0.0,
                "status": "open",
                "reason": reason or "MANUAL",
                "kraken_order_id": kraken_txid
            }
            
            self.positions[pair] = position
            
            position_size_usd = volume * entry_price
            
            logger.info(f"[POSITION] ✅ REAL POSITION OPENED: {pair} {side.upper()} {volume:.6f} @ ${entry_price:.6f} (Value: ${position_size_usd:.2f}) - TXID: {kraken_txid or 'N/A'}")
            return True
            
        except Exception as e:
            logger.error(f"Error opening position for {pair}: {e}", exc_info=True)
            return False
        
    def close_position(self, pair: str, exit_price: Optional[float] = None, 
                      reason: Optional[str] = None) -> Optional[dict]:
        """
        Pozíció zárása - ÉLES KERESKEDÉSSEL
        
        Args:
            pair: Trading pair
            exit_price: Kilépési ár (opcionális, ha None, akkor a TradeManager-től kapott ár lesz használva, ha van)
            reason: Zárás oka (opcionális)
            
        Returns:
            dict: Lezárt pozíció adatai vagy None
        """
        try:
            if pair not in self.positions:
                logger.warning(f"No open position found for {pair} to close.")
                return None
                
            position_to_close = self.positions[pair].copy() # Másolatot készítünk a módosítások előtt
            
            logger.info(f"[POSITION] 🔴 Attempting to close REAL position via TradeManager: {pair}")

            if not self.trade_manager:
                logger.error("[POSITION] ❌ TradeManager is not available. Cannot close position.")
                return None

            # Meghatározzuk az ellentétes oldalt a záráshoz
            close_side = "sell" if position_to_close["side"] == "buy" else "buy"

            close_order_result = self.trade_manager.place_order(
                pair=pair,
                side=close_side, # Az eredeti pozícióval ellentétes oldal
                order_type="market",
                volume=str(position_to_close["volume"]),
                # price=None # Market order
            )
            
            closed_successfully_on_exchange = False
            close_txid = None
            actual_exit_price = exit_price # Kezdetben a megadott, ha van

            if close_order_result:
                if close_order_result.get('error'):
                    error_message = close_order_result['error']
                    if isinstance(error_message, list): error_message = ", ".join(error_message)
                    logger.error(f"[POSITION] ⚠️ TradeManager close order ERROR for {pair}: {error_message}")
                    # Hiba esetén is folytatjuk a belső könyvelést, de jelezzük a problémát
                elif close_order_result.get('result') and close_order_result['result'].get('txid'):
                    txid_list = close_order_result['result']['txid']
                    if isinstance(txid_list, list) and len(txid_list) > 0:
                        close_txid = txid_list[0]
                    elif isinstance(txid_list, str):
                        close_txid = txid_list
                    
                    logger.info(f"[POSITION] ✅ TradeManager close order SUCCESS for {pair} - TXID: {close_txid}")
                    closed_successfully_on_exchange = True
                    
                    # Próbáljuk meg kinyerni a tényleges zárási árat, ha az API visszaadja
                    # Ez a rész API-specifikus lehet, a TradeManager-nek kellene ezt kezelnie
                    # Tegyük fel, hogy a 'descr' tartalmazza az árat: "sold 0.1 XBTUSD @ market"
                    if 'descr' in close_order_result['result'] and 'price' in close_order_result['result']['descr']:
                         # Ez egy placeholder, a tényleges árkinyerés a TradeManager feladata lenne
                         # actual_exit_price = parse_price_from_descr(close_order_result['result']['descr']['price'])
                         pass # Itt kellene implementálni az árkinyerést, ha az API adja
                else:
                    logger.warning(f"[POSITION] ⚠️ TradeManager close order for {pair} response did not contain expected TXID or error: {close_order_result}")
            else:
                logger.error(f"[POSITION] ❌ TradeManager close order FAILED for {pair} - no response.")

            # Ha nem kaptunk exit_price-t argumentumként, és a tőzsdei zárás sikertelen volt,
            # vagy nem tudtuk kinyerni az árat, akkor nem tudunk P&L-t számolni.
            # Ebben az esetben a pozíciót "error" státuszba helyezhetnénk, vagy megpróbálhatnánk később.
            # Mostani logika: ha nincs exit_price, és a tőzsdei zárás nem adott, akkor a P&L 0 lesz.
            if actual_exit_price is None and not closed_successfully_on_exchange:
                logger.warning(f"Cannot determine exit price for {pair} and exchange close failed or price not available. P&L might be inaccurate.")
                # Dönthetünk úgy, hogy nem zárjuk le a pozíciót belsőleg, ha a tőzsdei zárás sikertelen.
                # Vagy egy speciális státuszba helyezzük.
                # Mostani implementáció: belsőleg lezárjuk, de a P&L 0 lesz, ha nincs ár.

            # Pozíció adatainak frissítése
            position_to_close["kraken_close_order_id"] = close_txid
            position_to_close["close_time"] = time.time()
            position_to_close["status"] = "closed"
            position_to_close["hold_duration_seconds"] = position_to_close["close_time"] - position_to_close["open_time"]
            position_to_close["close_reason"] = reason or ("EXCHANGE_CLOSE_FAILED" if not closed_successfully_on_exchange and actual_exit_price is None else "MANUAL")
            
            if actual_exit_price is not None:
                position_to_close["exit_price"] = float(actual_exit_price)
                # P&L számítás a tényleges vagy megadott kilépési árral
                pnl = self._calculate_pnl_for_position(position_to_close, float(actual_exit_price))
                position_to_close["realized_pnl"] = pnl
            else:
                # Ha nincs kilépési ár, a P&L nem számítható pontosan.
                position_to_close["exit_price"] = None
                position_to_close["realized_pnl"] = 0.0 
                logger.warning(f"Position {pair} closed internally without a definitive exit price. Realized P&L set to 0.")

            if position_to_close["realized_pnl"] > 0:
                position_to_close["result"] = "WIN"
            elif position_to_close["realized_pnl"] < 0:
                position_to_close["result"] = "LOSS"
            else:
                position_to_close["result"] = "BREAKEVEN"
            
            del self.positions[pair]
            self.position_history.append(position_to_close)
            
            if len(self.position_history) > 1000: # Max history size
                self.position_history = self.position_history[-1000:]
                
            logger.info(f"[POSITION] ✅ REAL POSITION CLOSED (internally): {pair} P&L: ${position_to_close['realized_pnl']:.2f} (Reason: {position_to_close['close_reason']}) TXID: {close_txid or 'N/A'}")
            
            return {
                "pair": pair,
                "side": position_to_close["side"],
                "entry_price": position_to_close["entry_price"],
                "exit_price": position_to_close.get("exit_price"),
                "volume": position_to_close["volume"],
                "pnl": position_to_close["realized_pnl"],
                "status": "closed", # Vagy "closed_with_exchange_error" ha releváns
                "reason": position_to_close["close_reason"],
                "result": position_to_close["result"],
                "kraken_entry_order_id": position_to_close.get("kraken_order_id"),
                "kraken_close_order_id": close_txid
            }
            
        except Exception as e:
            logger.error(f"Error closing position for {pair}: {e}", exc_info=True)
            # Fontos lehet itt is megpróbálni a pozíciót valamilyen error státuszba helyezni,
            # vagy legalább loggolni, hogy a belső állapot eltérhet a tőzsdeitől.
            return None

    def _calculate_pnl_for_position(self, position_data: dict, current_or_exit_price: float) -> float:
        """
        Segédfüggvény P&L számításhoz egy adott pozíció adatai alapján.
        Args:
            position_data (dict): A pozíció szótára.
            current_or_exit_price (float): Az aktuális vagy kilépési ár.
        Returns:
            float: Profit/Loss érték.
        """
        entry_price = position_data["entry_price"]
        volume = position_data["volume"]
        side = position_data["side"]
        
        price_diff = 0
        if side == "buy": # Long
            price_diff = current_or_exit_price - entry_price
        elif side == "sell": # Short
            price_diff = entry_price - current_or_exit_price
        else:
            logger.warning(f"Unknown side '{side}' for P&L calculation of position {position_data.get('pair', 'N/A')}")
            return 0.0
            
        pnl = price_diff * volume
        return pnl

    def get_position(self, pair: str) -> Optional[dict]:
        """Pozíció lekérdezése"""
        return self.positions.get(pair)
        
    def get_all_positions(self) -> Dict[str, dict]:
        """Összes aktív pozíció lekérdezése (másolatként)"""
        return self.positions.copy()
        
    def calculate_unrealized_pnl(self, pair: str, current_price: float) -> float:
        """
        Egy nyitott pozíció nem realizált P&L számítása és frissítése.
        
        Args:
            pair: Trading pair
            current_price: Jelenlegi ár
            
        Returns:
            float: Nem realizált Profit/Loss érték vagy 0.0, ha nincs pozíció.
        """
        try:
            position = self.positions.get(pair)
            if not position or position["status"] != "open":
                return 0.0
            
            pnl = self._calculate_pnl_for_position(position, current_price)
            position["unrealized_pnl"] = pnl # Frissítjük a pozícióban
            return pnl
            
        except Exception as e:
            logger.error(f"Error calculating unrealized P&L for {pair}: {e}", exc_info=True)
            return 0.0
        
    def calculate_total_pnl_summary(self, current_prices: Dict[str, float]) -> dict:
        """
        Összes pozíció P&L-jének és egyéb statisztikáinak összefoglalása.
        
        Args:
            current_prices: Aktuális árak dict formában {pair: price}
            
        Returns:
            dict: Összesített P&L adatok és egyéb statisztikák.
        """
        try:
            total_unrealized_pnl = 0.0
            
            for pair, position_data in self.positions.items():
                if pair in current_prices and position_data["status"] == "open":
                    # Az unrealized P&L-t a calculate_unrealized_pnl metódus hívásával frissítjük és kapjuk meg
                    unrealized_pnl_for_pos = self.calculate_unrealized_pnl(pair, current_prices[pair])
                    total_unrealized_pnl += unrealized_pnl_for_pos
            
            # Realizált P&L a historikus adatokból
            total_realized_pnl = sum(pos.get("realized_pnl", 0.0) for pos in self.position_history if pos.get("realized_pnl") is not None)
            
            return {
                "total_unrealized_pnl": total_unrealized_pnl,
                "total_realized_pnl": total_realized_pnl,
                "grand_total_pnl": total_unrealized_pnl + total_realized_pnl,
                "active_positions_count": len(self.positions),
                "closed_positions_count": len(self.position_history)
            }
            
        except Exception as e:
            logger.error(f"Error calculating total P&L summary: {e}", exc_info=True)
            return {
                "total_unrealized_pnl": 0.0,
                "total_realized_pnl": 0.0,
                "grand_total_pnl": 0.0,
                "active_positions_count": 0,
                "closed_positions_count": len(self.position_history) # Még ha hiba is van, a lezártak számát tudjuk
            }
        
    def update_stop_loss(self, pair: str, new_stop_loss: Optional[float]) -> bool:
        """
        Stop loss frissítése egy nyitott pozíción.
        
        Args:
            pair: Trading pair.
            new_stop_loss: Új stop loss ár. None értékkel törölhető.
            
        Returns:
            bool: Sikeres volt-e a frissítés.
        """
        try:
            position = self.positions.get(pair)
            if not position:
                logger.warning(f"Position not found for stop loss update: {pair}")
                return False
            if position["status"] != "open":
                logger.warning(f"Cannot update stop loss for non-open position {pair} (status: {position['status']})")
                return False

            # Validáció: Buy pozíciónál a SL < entry_price (vagy < current_price)
            # Sell pozíciónál a SL > entry_price (vagy > current_price)
            # Ezt a logikát itt egyszerűsítjük, de éles rendszerben fontos lenne.
            if new_stop_loss is not None and not isinstance(new_stop_loss, (int, float)):
                logger.error(f"Invalid type for new_stop_loss for {pair}: {type(new_stop_loss)}")
                return False

            position["stop_loss"] = float(new_stop_loss) if new_stop_loss is not None else None
            logger.info(f"[POSITION] Updated stop loss for {pair}: ${new_stop_loss:.6f}" if new_stop_loss is not None else f"[POSITION] Removed stop loss for {pair}")
            return True
            
        except Exception as e:
            logger.error(f"Error updating stop loss for {pair}: {e}", exc_info=True)
            return False
        
    def update_take_profit(self, pair: str, new_take_profit: Optional[float]) -> bool:
        """
        Take profit frissítése egy nyitott pozíción.
        
        Args:
            pair: Trading pair.
            new_take_profit: Új take profit ár. None értékkel törölhető.
            
        Returns:
            bool: Sikeres volt-e a frissítés.
        """
        try:
            position = self.positions.get(pair)
            if not position:
                logger.warning(f"Position not found for take profit update: {pair}")
                return False
            if position["status"] != "open":
                logger.warning(f"Cannot update take profit for non-open position {pair} (status: {position['status']})")
                return False
            
            if new_take_profit is not None and not isinstance(new_take_profit, (int, float)):
                logger.error(f"Invalid type for new_take_profit for {pair}: {type(new_take_profit)}")
                return False

            position["take_profit"] = float(new_take_profit) if new_take_profit is not None else None
            logger.info(f"[POSITION] Updated take profit for {pair}: ${new_take_profit:.6f}" if new_take_profit is not None else f"[POSITION] Removed take profit for {pair}")
            return True
            
        except Exception as e:
            logger.error(f"Error updating take profit for {pair}: {e}", exc_info=True)
            return False
        
    def check_sl_tp_triggers(self, current_prices: Dict[str, float]) -> List[Dict[str, any]]:
        """
        Stop loss és take profit szintek ellenőrzése az aktuális árak alapján.
        Automatikusan nem zár pozíciót, csak visszaadja azokat, amiket zárni kellene.
        
        Args:
            current_prices: Aktuális árak {pair: price}.
            
        Returns:
            List[Dict[str, any]]: Azoknak a pozícióknak a listája, amelyeket zárni kellene,
                                   a zárás okával és az érintett árral.
                                   Pl: [{'pair': 'BTCUSD', 'reason': 'STOP_LOSS', 'price': 50000.0, 'position_data': {...}}]
        """
        triggered_actions = []
        
        # Másolatot készítünk a self.positions.items()-ről, hogy iterálás közben módosíthassuk (bár itt nem módosítunk)
        for pair, position_data in list(self.positions.items()):
            if position_data["status"] != "open" or pair not in current_prices:
                continue # Csak nyitott pozíciókat ellenőrzünk, amelyekhez van aktuális ár
                
            current_price = current_prices[pair]
            side = position_data["side"]
            stop_loss = position_data.get("stop_loss")
            take_profit = position_data.get("take_profit")
            
            trigger_info = None

            if side == "buy":
                if stop_loss is not None and current_price <= stop_loss:
                    trigger_info = {"reason": "STOP_LOSS", "price": stop_loss}
                elif take_profit is not None and current_price >= take_profit:
                    trigger_info = {"reason": "TAKE_PROFIT", "price": take_profit}
            elif side == "sell":
                if stop_loss is not None and current_price >= stop_loss:
                    trigger_info = {"reason": "STOP_LOSS", "price": stop_loss}
                elif take_profit is not None and current_price <= take_profit:
                    trigger_info = {"reason": "TAKE_PROFIT", "price": take_profit}
            
            if trigger_info:
                logger.info(f"[POSITION_TRIGGER] {pair} triggered {trigger_info['reason']} at current price ${current_price:.6f} (trigger level: ${trigger_info['price']:.6f})")
                triggered_actions.append({
                    "pair": pair,
                    "reason": trigger_info["reason"],
                    "trigger_price": trigger_info["price"], # Az SL/TP szint, ami aktiválódott
                    "current_price_at_trigger": current_price, # Az ár, aminél az aktiválódás történt
                    "position_data": position_data.copy() # A pozíció adatai másolatként
                })
                
        return triggered_actions
        
    def get_statistics(self) -> dict:
        """
        Pozíció statisztikák lekérdezése a lezárt pozíciók alapján.
        """
        try:
            # Csak azokat a pozíciókat vesszük figyelembe a historikus adatokból, amelyeknek van "realized_pnl" értéke
            closed_positions_with_pnl = [pos for pos in self.position_history if pos.get("realized_pnl") is not None and pos.get("status") == "closed"]
            
            if not closed_positions_with_pnl:
                return {
                    "total_trades": 0, "winning_trades": 0, "losing_trades": 0, "breakeven_trades": 0,
                    "win_rate_excluding_be": 0.0, "loss_rate_excluding_be": 0.0,
                    "total_profit_usd": 0.0, "average_pnl_usd": 0.0,
                    "max_profit_usd": 0.0, "max_loss_usd": 0.0,
                    "average_hold_duration_seconds": 0.0, "total_volume_traded_usd": 0.0, # Hozzáadva
                    "profit_factor": 0.0 # Hozzáadva
                }
                
            pnls = [pos["realized_pnl"] for pos in closed_positions_with_pnl]
            winning_trades_list = [pnl for pnl in pnls if pnl > 0]
            losing_trades_list = [pnl for pnl in pnls if pnl < 0]
            breakeven_trades_count = len([pnl for pnl in pnls if pnl == 0])
            
            total_trades = len(closed_positions_with_pnl)
            winning_trades_count = len(winning_trades_list)
            losing_trades_count = len(losing_trades_list)

            # Win rate számítása a nyerő és vesztő tradek alapján (breakeven nélkül)
            if (winning_trades_count + losing_trades_count) > 0:
                win_rate_excl_be = winning_trades_count / (winning_trades_count + losing_trades_count)
                loss_rate_excl_be = losing_trades_count / (winning_trades_count + losing_trades_count)
            else:
                win_rate_excl_be = 0.0
                loss_rate_excl_be = 0.0

            total_profit_usd = sum(pnls)
            average_pnl_usd = total_profit_usd / total_trades if total_trades else 0.0
            
            hold_durations = [pos.get("hold_duration_seconds", 0) for pos in closed_positions_with_pnl if pos.get("hold_duration_seconds") is not None]
            average_hold_duration_seconds = sum(hold_durations) / len(hold_durations) if hold_durations else 0.0

            # Teljes kereskedett volumen számítása (entry érték alapján)
            total_volume_traded_usd = sum(pos["volume"] * pos["entry_price"] for pos in closed_positions_with_pnl)

            # Profit Factor számítása
            total_gross_profit = sum(pnl for pnl in winning_trades_list)
            total_gross_loss = abs(sum(pnl for pnl in losing_trades_list)) # Abszolút érték
            profit_factor = total_gross_profit / total_gross_loss if total_gross_loss > 0 else float('inf') if total_gross_profit > 0 else 0.0


            return {
                "total_trades": total_trades,
                "winning_trades": winning_trades_count,
                "losing_trades": losing_trades_count,
                "breakeven_trades": breakeven_trades_count,
                "win_rate_excluding_be": win_rate_excl_be, # Nyerési arány (breakeven nélkül)
                "loss_rate_excluding_be": loss_rate_excl_be, # Veszteségi arány (breakeven nélkül)
                "total_profit_usd": total_profit_usd,
                "average_pnl_usd": average_pnl_usd,
                "max_profit_usd": max(pnls) if pnls else 0.0,
                "max_loss_usd": min(pnls) if pnls else 0.0, # Ez negatív lesz
                "average_hold_duration_seconds": average_hold_duration_seconds,
                "total_volume_traded_usd": total_volume_traded_usd,
                "profit_factor": profit_factor
            }
            
        except Exception as e:
            logger.error(f"Error getting statistics: {e}", exc_info=True)
            # Visszaadunk egy alapértelmezett struktúrát hiba esetén is, hogy a GUI ne omoljon össze
            return {
                "total_trades": 0, "winning_trades": 0, "losing_trades": 0, "breakeven_trades": 0,
                "win_rate_excluding_be": 0.0, "loss_rate_excluding_be": 0.0,
                "total_profit_usd": 0.0, "average_pnl_usd": 0.0,
                "max_profit_usd": 0.0, "max_loss_usd": 0.0,
                "average_hold_duration_seconds": 0.0, "total_volume_traded_usd": 0.0,
                "profit_factor": 0.0
            }
        
    def set_max_open_positions(self, max_positions_count: int):
        """Maximális nyitott pozíciók számának beállítása."""
        try:
            if not isinstance(max_positions_count, int) or max_positions_count < 0:
                logger.error(f"Invalid value for max_positions_count: {max_positions_count}. Must be a non-negative integer.")
                return
            self.max_positions = max_positions_count # 0 is lehet, ha le akarjuk tiltani az új pozíciók nyitását
            logger.info(f"[POSITION_CONFIG] Max open positions set to: {self.max_positions}")
        except Exception as e:
            logger.error(f"Error setting max open positions: {e}", exc_info=True)
        
    def clear_all_open_positions(self, current_prices: Optional[Dict[str, float]] = None, reason: str = "CLEAR_ALL_OPEN") -> List[dict]:
        """
        Összes nyitott pozíció zárása a megadott (vagy aktuális piaci) árakon.
        
        Args:
            current_prices: Aktuális árak {pair: price}. Ha None, a zárásnál az ár nem lesz meghatározva,
                            hacsak a close_position metódus nem tudja azt a TradeManager-től kinyerni.
            reason: A zárás oka.
            
        Returns:
            List[dict]: A lezárt pozíciók adatainak listája.
        """
        closed_positions_summary = []
        # Fontos, hogy a self.positions.keys() másolatán iteráljunk,
        # mert a close_position metódus módosítja a self.positions szótárat.
        for pair in list(self.positions.keys()):
            exit_price_for_pair = current_prices.get(pair) if current_prices else None
            logger.info(f"Attempting to clear position for {pair} with exit price: {exit_price_for_pair if exit_price_for_pair is not None else 'Market/Unknown'}")
            closed_info = self.close_position(pair, exit_price_for_pair, reason=reason)
            if closed_info:
                closed_positions_summary.append(closed_info)
        
        logger.info(f"[POSITION_OPS] All open positions cleared: {len(closed_positions_summary)} positions closed with reason '{reason}'.")
        return closed_positions_summary

    def get_open_positions_summary(self) -> dict:
        """
        Nyitott pozíciók összesítő adatai.
        """
        try:
            active_count = len(self.positions)
            total_value_usd = 0.0 # Jelenlegi összérték (unrealized P&L-lel együtt)
            total_initial_cost_usd = 0.0 # Kezdeti befektetés értéke
            
            # Itt szükségünk lenne az aktuális árakra a pontos unrealized P&L és jelenlegi érték számításához.
            # Mivel ez a metódus nem kapja meg az aktuális árakat, csak a kezdeti költséget tudjuk számolni.
            # Az unrealized P&L-t a pozíciókban tárolt utolsó ismert érték alapján vehetnénk, de az elavult lehet.

            for pair, position in self.positions.items():
                initial_cost_for_pos = position["volume"] * position["entry_price"]
                total_initial_cost_usd += initial_cost_for_pos
                # Az unrealized P&L-t itt nem frissítjük, mert nincsenek aktuális árak.
                # A `total_value_usd` számításához ez hiányzik.
                # total_value_usd += initial_cost_for_pos + position.get("unrealized_pnl", 0.0)


            return {
                "active_positions_count": active_count,
                "max_allowed_positions": self.max_positions,
                "total_initial_cost_usd": total_initial_cost_usd,
                # "current_total_value_usd": total_value_usd, # Ez aktuális árak nélkül pontatlan
                "available_slots": self.max_positions - active_count if self.max_positions >= active_count else 0,
                "position_history_count": len(self.position_history)
            }
            
        except Exception as e:
            logger.error(f"Error getting open positions summary: {e}", exc_info=True)
            return {
                "active_positions_count": 0,
                "max_allowed_positions": self.max_positions,
                "total_initial_cost_usd": 0.0,
                "available_slots": self.max_positions,
                "position_history_count": len(self.position_history)
            }

